<?php

$LANG = array(

# install.php
'L_INSTALL_TITLE'					=> 'Installacion',
'L_WRONG_PHP_VERSION'				=> 'PluXml requesís PHP 5 o superior per foncionar.',
'L_SELECT_LANG'						=> 'Seleccionatz vòstra lenga',
'L_INPUT_CHANGE'					=> 'Cambiar',
'L_DEFAULT_CATEGORY_TITLE'			=> 'Rubrica 1',
'L_DEFAULT_CATEGORY_URL'			=> 'rubrica-1',
'L_DEFAULT_STATIC_TITLE'			=> 'Estatic 1',
'L_DEFAULT_STATIC_URL'				=> 'estatic-1',
'L_DEFAULT_ARTICLE_TITLE'			=> 'Primièr article',
'L_DEFAULT_ARTICLE_URL'				=> 'primièr-article',
'L_DEFAULT_COMMENT_CONTENT'			=> 'Aquò es un primièr comentari !',
'L_ERR_PLUXML_ALREADY_INSTALLED'	=> 'PluXml es ja configurat !',
'L_ERR_MISSING_USER'				=> 'Volgatz entre-senhar lo nom del redactor !',
'L_ERR_MISSING_LOGIN'				=> 'Volgatz entre-senhar lo login de connexion !',
'L_ERR_MISSING_PASSWORD'			=> 'Volgatz entre-senhar un senhal !',
'L_ERR_PASSWORD_CONFIRMATION'		=> 'Confirmacion del senhal incorrècta !',
'L_PLUXML_INSTALLATION'				=> 'Installacion de PluXml',
'L_SITE_DESCRIPTION'				=> 'Blòg o Cms a l\'Xml !',
'L_VERSION'							=> 'version',
'L_USERNAME'						=> 'Nom de l\'administrator',
'L_LOGIN'							=> 'Identificant de connexion a l\'administracion',
'L_PASSWORD'						=> 'Senhal',
'L_PASSWORD_CONFIRMATION'			=> 'Confirmacion del senhal',
'L_INPUT_INSTALL'					=> 'Installar',
'L_TIMEZONE'						=> 'Fus orari',
'L_PWD_VERY_WEAK'					=> 'Senhal fòrça feble',
'L_PWD_WEAK'						=> 'Senhal feble',
'L_PWD_GOOD'						=> 'Senhal bon',
'L_PWD_STRONG'						=> 'Senhal fòrt',
);
?>
